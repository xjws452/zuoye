if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Page_Params {
    message?: string;
    blankRowColIndex?: Array<number>;
    board?: Array<Array<number>>;
}
class Page extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.__blankRowColIndex = new ObservedPropertyObjectPU([3, 3], this, "blankRowColIndex");
        this.__board = new ObservedPropertyObjectPU([
            [3, 11, 2, 6],
            [7, 1, 15, 5],
            [4, 8, 9, 13],
            [12, 10, 14, 0],
        ], this, "board");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Page_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.blankRowColIndex !== undefined) {
            this.blankRowColIndex = params.blankRowColIndex;
        }
        if (params.board !== undefined) {
            this.board = params.board;
        }
    }
    updateStateVars(params: Page_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__blankRowColIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__board.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__blankRowColIndex.aboutToBeDeleted();
        this.__board.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    private __blankRowColIndex: ObservedPropertyObjectPU<Array<number>>;
    get blankRowColIndex() {
        return this.__blankRowColIndex.get();
    }
    set blankRowColIndex(newValue: Array<number>) {
        this.__blankRowColIndex.set(newValue);
    }
    private __board: ObservedPropertyObjectPU<Array<Array<number>>>;
    get board() {
        return this.__board.get();
    }
    set board(newValue: Array<Array<number>>) {
        this.__board.set(newValue);
    }
    move(blankRow: number, blankCol: number, targetRow: number, targetCol: number) {
        let temp = this.board[blankRow][blankCol];
        this.board[blankRow][blankCol] = this.board[targetRow][targetCol];
        this.board[targetRow][targetCol] = temp;
        this.updateBoard();
    }
    updateBoard(): void {
        this.board = [...this.board];
    }
    handleMove(targetRow: number, targetCol: number) {
        if (this.isValidMove(targetRow, targetCol, this.blankRowColIndex[0], this.blankRowColIndex[1])) {
            this.move(this.blankRowColIndex[0], this.blankRowColIndex[1], targetRow, targetCol);
            this.blankRowColIndex = [targetRow, targetCol];
        }
    }
    isValidMove(row: number, col: number, blankRow: number, blankCol: number): boolean {
        return Math.abs(row - blankRow) + Math.abs(col - blankCol) === 1;
    }
    getBackgroundColorByValue(value: number): string {
        return value === 0 ? '#ffb627dd' : '#ff2638ec';
    }
    getButtonDisplayStrByValue(value: number): string {
        return value === 0 ? '' : value.toString();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/chapter2/IndexPage.ets(46:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, rowIndex: number) => {
                const row = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/chapter2/IndexPage.ets(48:9)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = (_item, colIndex) => {
                        const item = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel(this.getButtonDisplayStrByValue(item), { type: ButtonType.Normal });
                            Button.debugLine("entry/src/main/ets/pages/chapter2/IndexPage.ets(50:13)", "entry");
                            Button.width('70');
                            Button.height('70');
                            Button.backgroundColor(this.getBackgroundColorByValue(item));
                            Button.border({ width: 1, color: Color.White });
                        }, Button);
                        Button.pop();
                    };
                    this.forEachUpdateFunction(elmtId, row, forEachItemGenFunction, undefined, true, false);
                }, ForEach);
                ForEach.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.board, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Page";
    }
}
registerNamedRoute(() => new Page(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/chapter2/IndexPage", pageFullPath: "entry/src/main/ets/pages/chapter2/IndexPage", integratedHsp: "false" });
